import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
    export class AsignacionesService {
    // URL backend FastAPI
    private FAST_API = 'http://127.0.0.1:8000';

    constructor(private http: HttpClient) { }
    //! header es un objeto que se utiliza para enviar información adicional (el token en este caso) en las solicitudes HTTP
    private getHeaders() { //? método para obtener los headers con el token de autenticación
        // localstorage es un almacenamiento local en el navegador que permite guardar datos de forma persistente incluso después de cerrar la pestaña o el navegador. En este caso, se utiliza para almacenar el token de autenticación que se obtiene al iniciar sesión. El token se guarda en el localStorage para que pueda ser utilizado en futuras solicitudes al backend sin necesidad de volver a iniciar sesión cada vez. Al obtener el token del localStorage, se puede agregar a los headers de las solicitudes HTTP para autenticar al usuario y permitirle acceder a recursos protegidos en el backend.
        const token = localStorage.getItem('token'); // obtener el token del localStorage
        if (token) { // si el token existe, agregarlo a los headers
            return { headers: new HttpHeaders({ 'Authorization': `Bearer ${token}` })};
        } else { // si no hay token es que el usuario no ha iniciado sesion
            return {}; // o lanzar error / forzar login
        }
    }
    
    // obtener todas las asignaciones actuales
    getAsignaciones(): Observable<any[]> {
        return this.http.get<any[]>(`${this.FAST_API}/asignaciones`);
    }

    // obtener solo los alumnos que no tienen empresa
    getAlumnosLibres(): Observable<any[]> {
        return this.http.get<any[]>(`${this.FAST_API}/alumnos-libres`, this.getHeaders());
    }

    // Crear una nueva asignacion corregido por fin inshallah
    asignar(id_vacante: number, id_alumno: number): Observable<any> {
        const url = `${this.FAST_API}/asignaciones`;

        // Creamos el objeto que el backend espera recibir en el body
        const body = {
        id_vacante: id_vacante,
        id_alumno: id_alumno
        };

        // Enviamos el body como segundo argumento
        return this.http.post(url, body, this.getHeaders());
    }

    // eliminar una asignacion
    borrarAsignacion(id_asig: number): Observable<any> {
        return this.http.delete(`${this.FAST_API}/asignaciones/${id_asig}`, this.getHeaders());
    }
}
