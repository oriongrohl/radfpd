import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class VacantesService {
    private FAST_API = 'http://127.0.0.1:8000/vacantes';

    constructor(private http: HttpClient) { }

    private getHeaders() {
      const token = localStorage.getItem('token');
      if (token) {
        return {
          headers: new HttpHeaders({ 'Authorization': `Bearer ${token}` })
        };
      } else {
        return {}; // o lanzar error / forzar login
      }
    }

    getVacantes(): Observable<any[]> {
        return this.http.get<any[]>(this.FAST_API);
    }

    getCiclos(): Observable<any[]> {
      return this.http.get<any[]>(`http://127.0.0.1:8000/ciclos`);
    }

    crearVacante(vacante: any): Observable<any> {
        return this.http.post<any>(this.FAST_API, vacante, this.getHeaders());
    }

    actualizarVacante(id: number, vacanteCompleta: any): Observable<any> {
      return this.http.put<any>(`${this.FAST_API}/${id}`, vacanteCompleta, this.getHeaders());
    }

    borrarVacante(id: number): Observable<any> {
        return this.http.delete<any>(`${this.FAST_API}/${id}`, this.getHeaders());
    }

    getAsignaciones(): Observable<any[]> {
      return this.http.get<any[]>(`http://127.0.0.1:8000/asignaciones`);
    }

    borrarAsignacion(idAsig: number): Observable<any> {
      return this.http.delete(`http://127.0.0.1:8000/asignaciones/${idAsig}`, this.getHeaders());
    }

    getAlumnosLibres(): Observable<any[]> {
      return this.http.get<any[]>(`http://127.0.0.1:8000/alumnos-libres`, this.getHeaders());
    }

    asignarAlumno(idVacante: number, idAlumno: number): Observable<any> {
      // el backend espera {id_vacante, id_alumno} en el body
      return this.http.post(`http://127.0.0.1:8000/asignaciones`, { id_vacante: idVacante, id_alumno: idAlumno }, this.getHeaders());
    }


}
